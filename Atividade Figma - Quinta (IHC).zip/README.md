
  # Atividade Figma - Quinta (IHC)

  This is a code bundle for Atividade Figma - Quinta (IHC). The original project is available at https://www.figma.com/design/QCmptzkNFVf6G7c09ifxf4/Atividade-Figma---Quinta--IHC-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  