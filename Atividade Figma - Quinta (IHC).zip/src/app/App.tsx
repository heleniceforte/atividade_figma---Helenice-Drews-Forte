import { StatsCard } from "./components/StatsCard";
import { ProgressChart } from "./components/ProgressChart";
import { DataTable } from "./components/DataTable";
import { motion } from "motion/react";

export default function App() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 p-8">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Header */}
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="space-y-2"
        >
          <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 bg-clip-text text-transparent">
            Dashboard
          </h1>
          <p className="text-gray-600 text-lg">Visão geral dos seus dados e métricas</p>
        </motion.div>

        {/* Elemento 1: Cards de Estatísticas */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <StatsCard
            title="Total de Usuários"
            value="2,847"
            description="desde o mês passado"
            trend={12.5}
            icon="users"
          />
          <StatsCard
            title="Receita Total"
            value="R$ 48,592"
            description="desde o mês passado"
            trend={8.2}
            icon="revenue"
          />
          <StatsCard
            title="Taxa de Crescimento"
            value="23.1%"
            description="desde o mês passado"
            trend={-2.4}
            icon="growth"
          />
        </div>

        {/* Elemento 2: Gráfico de Progresso */}
        <ProgressChart />

        {/* Elemento 3: Tabela de Dados */}
        <DataTable />
      </div>
    </div>
  );
}