import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { TrendingUp, Users, DollarSign } from "lucide-react";
import { motion } from "motion/react";

interface StatsCardProps {
  title: string;
  value: string;
  description: string;
  trend: number;
  icon: "users" | "revenue" | "growth";
}

export function StatsCard({ title, value, description, trend, icon }: StatsCardProps) {
  const icons = {
    users: Users,
    revenue: DollarSign,
    growth: TrendingUp,
  };

  const iconColors = {
    users: "bg-blue-500",
    revenue: "bg-emerald-500",
    growth: "bg-purple-500",
  };

  const Icon = icons[icon];
  const isPositive = trend > 0;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      whileHover={{ y: -5, transition: { duration: 0.2 } }}
    >
      <Card className="relative overflow-hidden border-0 shadow-xl hover:shadow-2xl transition-all duration-300 bg-gradient-to-br from-white to-gray-50">
        <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-blue-100/20 to-purple-100/20 rounded-full -mr-16 -mt-16" />
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 relative z-10">
          <CardTitle className="text-sm font-medium text-gray-600">{title}</CardTitle>
          <div className={`${iconColors[icon]} p-2.5 rounded-xl shadow-lg`}>
            <Icon className="h-5 w-5 text-white" />
          </div>
        </CardHeader>
        <CardContent className="relative z-10">
          <div className="text-3xl font-bold bg-gradient-to-r from-gray-900 to-gray-700 bg-clip-text text-transparent">
            {value}
          </div>
          <p className="text-xs text-gray-500 mt-2 flex items-center gap-1">
            <span className={`font-semibold px-2 py-0.5 rounded-full ${isPositive ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"}`}>
              {isPositive ? "+" : ""}{trend}%
            </span>
            <span>{description}</span>
          </p>
        </CardContent>
      </Card>
    </motion.div>
  );
}