import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "./ui/table";
import { Badge } from "./ui/badge";
import { motion } from "motion/react";
import { ArrowUpRight } from "lucide-react";

const tableData = [
  { id: 1, nome: "Ana Silva", status: "Ativo", valor: "R$ 1.200", data: "15/04/2026" },
  { id: 2, nome: "Bruno Costa", status: "Pendente", valor: "R$ 850", data: "14/04/2026" },
  { id: 3, nome: "Carla Santos", status: "Ativo", valor: "R$ 2.100", data: "13/04/2026" },
  { id: 4, nome: "Diego Oliveira", status: "Inativo", valor: "R$ 450", data: "12/04/2026" },
  { id: 5, nome: "Elena Rodrigues", status: "Ativo", valor: "R$ 1.750", data: "11/04/2026" },
];

export function DataTable() {
  const getStatusVariant = (status: string): "default" | "secondary" | "destructive" => {
    switch (status) {
      case "Ativo":
        return "default";
      case "Pendente":
        return "secondary";
      case "Inativo":
        return "destructive";
      default:
        return "default";
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "Ativo":
        return "bg-emerald-100 text-emerald-700 border-emerald-200";
      case "Pendente":
        return "bg-amber-100 text-amber-700 border-amber-200";
      case "Inativo":
        return "bg-red-100 text-red-700 border-red-200";
      default:
        return "bg-gray-100 text-gray-700 border-gray-200";
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.4 }}
    >
      <Card className="border-0 shadow-xl bg-gradient-to-br from-white to-gray-50/50">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-2xl bg-gradient-to-r from-gray-900 to-gray-600 bg-clip-text text-transparent">
                Transações Recentes
              </CardTitle>
              <CardDescription className="mt-1">Lista de transações dos últimos 5 dias</CardDescription>
            </div>
            <button className="flex items-center gap-1 text-sm text-blue-600 hover:text-blue-700 font-medium transition-colors">
              Ver todas
              <ArrowUpRight className="h-4 w-4" />
            </button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="rounded-xl border border-gray-200 overflow-hidden">
            <Table>
              <TableHeader>
                <TableRow className="bg-gradient-to-r from-gray-50 to-blue-50/30 hover:from-gray-50 hover:to-blue-50/30">
                  <TableHead className="font-semibold text-gray-700">Nome</TableHead>
                  <TableHead className="font-semibold text-gray-700">Status</TableHead>
                  <TableHead className="font-semibold text-gray-700">Valor</TableHead>
                  <TableHead className="text-right font-semibold text-gray-700">Data</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {tableData.map((item, index) => (
                  <motion.tr
                    key={item.id}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.3, delay: 0.5 + index * 0.1 }}
                    className="group hover:bg-blue-50/50 transition-colors"
                  >
                    <TableCell className="font-medium text-gray-900">{item.nome}</TableCell>
                    <TableCell>
                      <span className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold border ${getStatusColor(item.status)}`}>
                        {item.status}
                      </span>
                    </TableCell>
                    <TableCell className="font-semibold text-gray-900">{item.valor}</TableCell>
                    <TableCell className="text-right text-gray-600">{item.data}</TableCell>
                  </motion.tr>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}